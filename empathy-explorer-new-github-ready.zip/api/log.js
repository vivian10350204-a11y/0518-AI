module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  // 選用功能：如果你有 Google Apps Script Web App，請在 Vercel 環境變數新增 GAS_URL。
  // 沒設定 GAS_URL 時，這支 API 會直接回傳 ok，不會影響遊戲運作。
  const gasUrl = process.env.GAS_URL;
  if (!gasUrl) {
    return res.status(200).json({ ok: true, message: 'GAS_URL not set; skipped logging.' });
  }

  try {
    const gasRes = await fetch(gasUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body || {})
    });

    const text = await gasRes.text();
    return res.status(200).json({ ok: true, status: gasRes.status, response: text });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ ok: false, error: 'Failed to forward log to GAS.' });
  }
};
