const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';

function localFallback(levelIndex, answer = '') {
  const text = String(answer).trim();
  let stars = '再想一想，你可以做得更好！';
  let feedback = '你有努力回答了，不過這樣的應對方式可能還不夠具體。可以再想想如何用「安全、尊重、陪伴、協助」的方式幫助同學。';
  let score = 0;

  if (Number(levelIndex) === 3) {
    if (/(先確認安全|先讓大家退開|陪阿傑冷靜|理解他很煩躁|分工幫忙|安撫其他同學|不嘲笑|等他平靜)/.test(text)) {
      stars = '⭐⭐⭐⭐⭐⭐⭐ 全方位的安全與同理守護者';
      feedback = '太棒了！你不僅顧及現場安全，也兼顧環境整理與旁人安撫，更能用不貼標籤的方式理解阿傑。';
      score = 7;
    } else if (/(冷靜|陪他|慢慢說|深呼吸|帶去旁邊|安靜的地方|先休息|不要刺激他)/.test(text)) {
      stars = '⭐⭐⭐⭐⭐ 具有優秀的情緒覺察力與安撫技巧';
      feedback = '你展現了很好的情緒覺察，知道先降低刺激、陪伴同學冷靜，這是很重要的同理行動。';
      score = 5;
    } else if (/(找老師|叫老師|通知老師|幫忙|撿水果|收拾)/.test(text)) {
      stars = '⭐⭐⭐ 具備協助意識，但互動較少';
      feedback = '你能注意到狀況並尋求老師協助或幫忙清理，已經不錯。下次可以再加入一點對阿傑的安撫與關心。';
      score = 3;
    } else if (/(不要鬧|好可怕|神經病|活該|罵他|叫他閉嘴)/.test(text)) {
      stars = '⭐ 需要學習同理心';
      feedback = '責罵或嘲笑可能會讓情緒更失控。可以試著先保持距離、降低刺激，並請老師協助。';
      score = 1;
    }
  }

  if (Number(levelIndex) === 4) {
    if (/(讓他覺得安心|不催他|慢慢陪他|不讓他覺得被可憐|主動陪伴|尊重他的感受|不貼標籤|自然邀請)/.test(text)) {
      stars = '⭐⭐⭐⭐⭐⭐⭐ 兼具深度同理與尊重的完美夥伴';
      feedback = '非常棒！你提供的是平等、自然又尊重的接納，能降低小華的壓力，也讓他更安心地融入團體。';
      score = 7;
    } else if (/(小聲問|不讓大家注意|陪他|慢慢聊|不逼他|給他安全感|自然邀請)/.test(text)) {
      stars = '⭐⭐⭐⭐⭐ 心思細膩，懂得保護他人的自尊';
      feedback = '你很貼心，能注意到小華可能害怕被大家注視，所以用小聲、自然的方式邀請他。';
      score = 5;
    } else if (/(幫他喊人|大聲問|誰要跟他一組|直接拉他過來|問他要不要一組|一起|加入)/.test(text)) {
      stars = '⭐⭐⭐ 出發點良善，但方法可以更貼心';
      feedback = '你願意幫忙很棒，但大聲張揚可能會讓小華更尷尬。可以改成私下、小聲、自然地邀請。';
      score = 3;
    } else if (/(不理他|不關我的事|他很怪|不想跟他同組|讓老師處理)/.test(text)) {
      stars = '⭐ 需要培養關懷與接納';
      feedback = '選擇冷漠可能會讓同學更孤單。可以試著用小小的主動關心，讓班級更友善。';
      score = 1;
    }
  }

  return { stars, feedback, score };
}

function extractJson(content) {
  try { return JSON.parse(content); } catch (_) {}
  const match = String(content).match(/\{[\s\S]*\}/);
  if (match) {
    try { return JSON.parse(match[0]); } catch (_) {}
  }
  return null;
}

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { levelIndex, title, question, answer } = req.body || {};
  const fallback = localFallback(levelIndex, answer);

  if (!process.env.AI_KEY) {
    return res.status(200).json({ ...fallback, source: 'fallback' });
  }

  try {
    const prompt = `你是國小融合教育遊戲的AI老師。請根據學生答案評分。\n\n關卡：${title}\n題目：${question}\n學生回答：${answer}\n\n請只輸出JSON，不要加markdown。格式：{"stars":"評語標題，可含星星","feedback":"給國小學生看的溫暖具體回饋，80-150字","score":0到7的整數}\n評分重點：安全、同理、尊重、具體協助、避免嘲笑或貼標籤。`;

    const aiRes = await fetch(OPENROUTER_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.AI_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://vercel.app',
        'X-Title': 'Empathy Explorer'
      },
      body: JSON.stringify({
        model: process.env.OPENROUTER_MODEL || 'openrouter/free',
        messages: [
          { role: 'system', content: '你會用繁體中文回覆，並且嚴格輸出JSON。' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.4
      })
    });

    if (!aiRes.ok) throw new Error(await aiRes.text());
    const data = await aiRes.json();
    const content = data?.choices?.[0]?.message?.content || '';
    const parsed = extractJson(content);
    if (!parsed) throw new Error('AI did not return JSON');

    const score = Math.max(0, Math.min(7, Number(parsed.score ?? fallback.score)));
    return res.status(200).json({
      stars: parsed.stars || fallback.stars,
      feedback: parsed.feedback || fallback.feedback,
      score,
      source: 'openrouter'
    });
  } catch (error) {
    console.error(error);
    return res.status(200).json({ ...fallback, source: 'fallback-after-error' });
  }
};
