# 同理心探索家：校園大冒險

這是一個可以部署到 GitHub + Vercel 的靜態網頁專案，包含：

- `index.html`：遊戲主頁面
- `api/feedback.js`：OpenRouter AI 回饋 API
- `api/log.js`：選用的 Google Apps Script 紀錄 API
- `vercel.json`：Vercel 部署設定
- `assets/`：建議放圖片與音檔

## 需要另外放入的素材

因為原始 HTML 會讀取下列本機素材，請把這些檔案放在專案根目錄，或自行修改 `index.html` 內的檔名：

- `ChatGPT Image 1.png`
- `ChatGPT Image 2.png`
- `ChatGPT Image 3.png`
- `ChatGPT Image 4.png`
- `ChatGPT Image 5.png`
- `小手心花園.mp3`
- `ttsmaker-file-2026-5-21-17-5-4.mp3`
- `ttsmaker-file-2026-5-21-17-3-40.mp3`

## Vercel 環境變數

到 Vercel 專案的 Settings → Environment Variables 新增：

| Name | 說明 |
|---|---|
| `AI_KEY` | OpenRouter API Key，必填，給 AI 回饋用 |
| `OPENROUTER_MODEL` | 可不填，預設使用 `openrouter/free` |
| `GAS_URL` | 可不填，如果要記錄到 Google 試算表才需要 |

## 本機預覽

可以直接打開 `index.html` 預覽畫面。  
但 `/api/feedback` 和 `/api/log` 需要部署到 Vercel 後才會正常運作。
